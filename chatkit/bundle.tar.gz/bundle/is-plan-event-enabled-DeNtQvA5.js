function l(e,d){var o,i;return typeof d?.enabled=="boolean"?d.enabled:(i=(o=e?.__default)===null||o===void 0?void 0:o.enabled)!==null&&i!==void 0?i:!0}export{l as i};
